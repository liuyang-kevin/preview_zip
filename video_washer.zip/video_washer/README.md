AI 洗稿视频自动化工具

```
git add . && git commit -m "增加分割可拖拽view" && git push
```

# 编译上的坑

```bash
# vs installer怎么装NuGet环境变量都没有, 需要手动装一下,插件需要这个
winget install Microsoft.NuGet
```

# 使用的库

## https://github.com/bitsdojo/bitsdojo_window

去除桌面端默认的窗口, 自定义 UI

## import 'package:args/args.dart';

提供 cli 参数处理, 在 dart 代码中,加入一些 cli 功能

# 关于 webview

试验了几个, 基本都是不能用

# 利用 GitHub Action

https://github.com/subosito/flutter-action

https://github.com/actions/runner-images

# 可选 UI 方案

https://github.com/topics/flutter-desktop-template
https://github.com/leanflutter/awesome-flutter-desktop

https://mahanrahmati.github.io/arna_demo/#/

https://pub.dev/packages/multi_split_view

https://bdlukaa.github.io/fluent_ui/
仿制 win 的 fluentUI (非必须)
https://pub.dev/packages/macos_ui
mac 仿制

https://pub.dev/packages/desktop
感觉这个 UI 比较轻量

https://pub.dev/packages/menu_bar
桌面上的 top 菜单, flutter 实现

https://pub.dev/packages/msix
win 打包工具

https://pub.dev/packages/sliding_up_panel2
拖拽 panel, 不太好用

Flutter Gallery’s repo.
flutter_platform_widgets, which does a similar job in choosing widgets according to the platform, but for iOS and Android (Cupertino and Material UI).
macos_ui and fluent_ui, which were used extensively here.
bitsdojo_window, a really useful package for customizing the appearance of the window for each platform.
msix, to build the required installer of the app for the Microsoft Store.

# TODO:

- [ ] 统一解压路径, 增加 cache 功能,点击清理空间
- [ ] 优化 UI
- [ ] 增加 app 图标
- [ ] 这个库不错,可以后续搞电子书 https://pub.dev/packages/epub_view

# 可能需要的文章

https://smazee.com/blog/how-to-run-the-python-code-in-the-flutter-app
