import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:provider/provider.dart';
import 'package:multi_split_view/multi_split_view.dart';

import '../inner_server.dart';
import '../model/vm/global.dart';
import '../widgets/base/app.dart';
import '../widgets/desktop_drop_files.dart';
import '../widgets/folder_tree_view.dart';
import '../widgets/menu_bar.dart';
import 'webview_page.dart';

class ProjectPage extends StatefulWidget {
  const ProjectPage({super.key});

  @override
  createState() => _ProjectPageState();
}

class _ProjectPageState extends State<ProjectPage> {
  bool autoPreviewDone = false;
  bool isOpenInDetailPage = false;
  final MultiSplitViewController _multiSplitViewController =
      MultiSplitViewController(areas: [Area(minimalSize: 350, weight: .25), Area(minimalWeight: .25)]);
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final body = Expanded(
      child: ChangeNotifierProvider(
        create: (context) => GlobalVM(),
        child: Center(
          child: MultiSplitViewTheme(
            data: MultiSplitViewThemeData(
              dividerThickness: 4,
              dividerPainter: DividerPainters.grooved1(
                  color: Colors.indigo[100]!,
                  highlightedColor: Colors.indigo[900]!,
                  highlightedBackgroundColor: borderColor),
            ),
            child: MultiSplitView(
              controller: _multiSplitViewController,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FilesDragTarget(
                      onDragDone: (_) {
                        setState(() {
                          autoPreviewDone = false;
                        });
                      },
                      onClickZipFileBtn: (folderPath) {
                        if (isOpenInDetailPage) {
                          Navigator.pushNamed(context, '/detail', arguments: {'folderPath': folderPath});
                        } else {
                          Provider.of<GlobalVM>(context, listen: false).updateUnzipFloder(folderPath);
                        }
                      },
                    ),
                    Flexible(
                      flex: 1,
                      child: Consumer<GlobalVM>(
                        builder: (context, value, child) {
                          print('value.folderPath ${value.folderPath}');
                          if (value.folderPath.isEmpty) return Text('拖拽');
                          if (isOpenInDetailPage) {
                            SchedulerBinding.instance.addPostFrameCallback((_) {
                              // 检查文件夹是否包含index.html
                              if (!autoPreviewDone && InnerServer.hasIndexHtml(value.folderPath)) {
                                setState(() {
                                  autoPreviewDone = true;
                                });
                                Navigator.pushNamed(context, '/detail', arguments: {'folderPath': value.folderPath});
                              } else {}
                            });
                          }

                          return FolderTreeView(folderPath: value.folderPath);
                        },
                      ),
                    )
                  ],
                ),
                Consumer<GlobalVM>(
                  builder: (context, value, child) {
                    Widget webviewWithServer = const Text("未实现");
                    if (value.folderPath.isEmpty) {
                      return const Text("拖拽zip预览");
                    }
                    if (Platform.isWindows) {
                      print('asdfasdfasdfasdf, ${value.folderPath}');
                      webviewWithServer = FutureBuilder(
                          future: InnerServer.startServer(value.folderPath, 8080),
                          builder: (context, snap) {
                            return const Center(child: WinBrowser());
                          });
                    }
                    return webviewWithServer;
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );

    if (Platform.isWindows) {
      return ScaffoldWithWindow(
        body: body,
        menuBar: const MenuBarWrapper(),
      );
    }

    return Scaffold(appBar: AppBar(title: const Text('拖拽并显示Zip文件路径')), body: body);
  }
}
