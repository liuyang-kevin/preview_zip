import 'dart:io';

import 'package:archive/archive.dart';
import 'package:cross_file/cross_file.dart';
import 'package:desktop_drop/desktop_drop.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../model/vm/global.dart';

class FilesDragTarget extends StatefulWidget {
  final void Function(DropDoneDetails)? onDragDone;
  final void Function(String)? onClickZipFileBtn;
  const FilesDragTarget({Key? key, this.onDragDone, this.onClickZipFileBtn}) : super(key: key);

  @override
  createState() => _FilesDragTargetState();
}

class _FilesDragTargetState extends State<FilesDragTarget> {
  Future<String> _unzipToTempFolder(String zipFilePath) async {
    try {
      Directory tempDir = await getTemporaryDirectory();
      String tempPath = tempDir.path;

      // Read the Zip file
      List<int> bytes = File(zipFilePath).readAsBytesSync();
      Archive archive = ZipDecoder().decodeBytes(bytes);
      String unZipFloderPath = "";
      if (archive.isNotEmpty && !archive.first.isFile) {
        unZipFloderPath = path.join(tempPath, archive.first.name);
      }
      // Extract the contents to the temporary folder
      for (ArchiveFile file in archive) {
        String filePath = path.join(tempPath, file.name);
        // Ensure filePath is a directory before creating the file
        if (file.isFile) {
          // Create the parent directory if it doesn't exist
          Directory(path.dirname(filePath)).createSync(recursive: true);
          // Create and write the file
          File(filePath)
            ..createSync()
            ..writeAsBytesSync(file.content);
        } else {
          // print(filePath);
        }
      }

      print('Zip file extracted to: $tempPath');
      // Show a SnackBar message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: SelectableText('$unZipFloderPath'),
          // duration: Duration(days: 365),
          duration: Duration(seconds: 3),
          action: SnackBarAction(
            label: 'Dissmiss',
            textColor: Colors.yellow,
            onPressed: () {
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
            },
          ),
        ),
      );

      Provider.of<GlobalVM>(context, listen: false).updateUnzipFloder(unZipFloderPath);
      return unZipFloderPath;
    } catch (e) {
      print('Error extracting Zip file: $e');
    }
    return '';
  }

  final List<XFile> _list = [];

  bool _dragging = false;

  @override
  Widget build(BuildContext context) {
    return DropTarget(
      onDragDone: (detail) {
        setState(() {
          _list.addAll(detail.files);
        });
        if (detail.files.isNotEmpty) {
          var file = detail.files.first;
          _unzipToTempFolder(file.path);
        }
        widget.onDragDone?.call(detail);
      },
      onDragEntered: (detail) {
        setState(() {
          _dragging = true;
        });
      },
      onDragExited: (detail) {
        setState(() {
          _dragging = false;
        });
      },
      child: Container(
        width: double.infinity,
        constraints: const BoxConstraints(maxHeight: 350),
        color: _dragging ? Colors.blue.withOpacity(0.4) : Colors.black26,
        child: _list.isEmpty
            ? const Center(child: Text("Drop here"))
            : SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    ..._list.map((e) => TextButton(
                        onPressed: () {
                          _unzipToTempFolder(e.path).then((path) => widget.onClickZipFileBtn?.call(path));
                        },
                        child: Text(e.name)))
                  ],
                ),
              ),
      ),
    );
  }
}
