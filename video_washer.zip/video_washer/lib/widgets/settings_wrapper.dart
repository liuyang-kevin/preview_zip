import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../model/config/sys.dart';
import 'base/app.dart';

class SettingsWrapper extends StatefulWidget {
  final Widget child;
  const SettingsWrapper({Key? key, required this.child}) : super(key: key);

  @override
  createState() => _SettingsWrapperState();
}

class _SettingsWrapperState extends State<SettingsWrapper> {
  late SysSettingsVM _notifier;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _notifier = Provider.of<SysSettingsVM>(context, listen: false);
    _notifier.addListener(_listener);
  }

  @override
  void dispose() {
    _notifier.removeListener(_listener);
    super.dispose();
  }

  // 监听器方法
  void _listener() {
    if ([SettingsStatus.loading, SettingsStatus.updating].indexOf(_notifier.settingsStatus) > 0) {
      _isLoading = true;
    } else if (_notifier.settingsStatus == SettingsStatus.loaded) {
      _isLoading = false;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return _isLoading ? _buildLoading() : widget.child;
  }

  Widget _buildLoading() {
    return const BaseApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Settings loading...', style: TextStyle(fontSize: 16)),
            ],
          ),
        ),
      ),
    );
  }
}
