// ignore_for_file: avoid_print

import 'dart:io';

import 'package:args/args.dart';
import 'package:flutter/material.dart';

import 'logger.dart';

class CommandLineOptions {
  late ArgParser parser = ArgParser();
  late ArgResults args;

  // Constructor
  CommandLineOptions() {
    // Define options and flags
    // parser.addOption('name');
    // parser.addOption('mode', abbr: 'm', defaultsTo: 'debug', allowed: ['debug', 'release']);
    // parser.addFlag('verbose', abbr: 'v', negatable: false);

    // Set mandatory option
    // parser.addOption('mandatory', mandatory: true);

    // Add version command
    parser.addFlag('version', abbr: 'v', negatable: false, help: 'Print the version of the application');
    // Add doctor command
    parser.addFlag('doctor', negatable: false, help: 'Run doctor command');

    // Define callbacks
    // parser.addOption('callback', callback: (value) => _handleCallback(value));
    // parser.addFlag('verbose_callback', callback: (value) => _handleVerboseCallback(value));
  }

  // Method to parse command line arguments
  void parse(List<String> arguments) {
    try {
      args = parser.parse(arguments);
      print(args);
      print(args['version']);
      if (args['version']) {
        logger.i('Version 0.0.1');
        // exit(0);
        runApp(const MaterialApp(
          debugShowCheckedModeBanner: false,
          home: Scaffold(body: Text('Version 0.0.1')),
        ));
      } else if (args['doctor']) {
        logger.i('doctor \n Version 0.0.1');
        // exit(0);
        runApp(const MaterialApp(
          debugShowCheckedModeBanner: false,
          home: Scaffold(body: Text('doctor \n Version 0.0.1')),
        ));
      }
    } catch (e) {
      print(e);
    }
  }

  // Method to initialize options
  void testOptionsAndExit() {
    // Access options and perform initialization
    String? name = args['name'];
    String? mode = args['mode'];
    bool? verbose = args['verbose'];

    // Initialize mandatory option
    // bool? mandatory = args['mandatory'];

    // Print initialized options
    print('Name: $name');
    print('Mode: $mode');
    print('Verbose: $verbose');
    // print('Mandatory: $mandatory');

    exit(0);
  }

  // Callback function for 'callback' option
  void _handleCallback(String? value) {
    print('Callback value: $value');
  }

  // Callback function for 'verbose_callback' flag
  void _handleVerboseCallback(bool value) {
    if (value) {
      print('Verbose callback');
      exit(0);
    }
  }

  void _handleVersionCallback(bool value) {
    logger.i('Version 0.0.1');
    exit(0);
  }

  void _handleDoctorCallback(bool value) {
    print('_handleDoctorCallback 0.0.1');
    exit(0);
  }
}
