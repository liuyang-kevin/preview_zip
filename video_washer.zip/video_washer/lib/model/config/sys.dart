import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:video_washer/cli/logger.dart';
import 'dart:developer' as developer;

import 'package:yaml/yaml.dart';

import '../../utils/yaml.dart';

Future<String> getConfigFilePath() async {
  final directory = await getApplicationSupportDirectory();
  return path.join(directory.path, 'config', 'config.yml');
}

Future<void> logPathProviderPaths() async {
  try {
    // 获取应用文档目录
    final appDocDir = await getApplicationDocumentsDirectory();
    developer.log('Application Documents Directory: ${appDocDir.path}');

    // 获取应用临时目录
    final appTempDir = await getTemporaryDirectory();
    developer.log('Temporary Directory: ${appTempDir.path}');

    //
    final appSupportDir = await getApplicationSupportDirectory();
    developer.log('Application Support  Directory: ${appSupportDir.path}');

    // 获取应用库目录
    if (Platform.isWindows) {
    } else {
      final appLibDir = await getLibraryDirectory();
      developer.log('Library Directory: ${appLibDir?.path}');
    }

    // 获取应用外部存储目录
    if (Platform.isWindows) {
    } else {
      final appExtStorageDir = await getExternalStorageDirectory();
      developer.log('External Storage Directory: ${appExtStorageDir?.path}');
    }
  } catch (e) {
    developer.log('Error logging path provider paths: $e');
  }
}

enum SettingsStatus {
  loading, // 加载中
  loaded, // 加载完毕
  saving, // 保存中
  updating, // 更新中
}

Future<Map<String, dynamic>> loadYamlConfig(String filePath) async {
  try {
    // 读取 YAML 文件内容
    final file = File(filePath);
    final yamlString = await file.readAsString();

    // 解析 YAML 文件内容
    final yamlMap = loadYaml(yamlString);

    // 将解析后的 YAML 映射转换为 Map<String, dynamic>
    if (yamlMap is Map) {
      return yamlMap.cast<String, dynamic>();
    } else {
      throw FormatException('Invalid YAML format');
    }
  } catch (e) {
    developer.log('Error loading YAML config file: $e');
    return {}; // 返回一个空的配置，或者根据需要返回默认配置
  }
}

// 保存配置到YAML文件
void saveConfigToYamlFile(Map<String, dynamic> configContent, String filePath) {
  // 将Map转换为YAML格式的字符串
  var yamlString = '';

  configContent.forEach((key, value) {
    yamlString += '$key: $value\n';
  });

  // 写入YAML内容到文件
  File(filePath).writeAsStringSync(yamlString);
}

class SysSettingsVM with ChangeNotifier {
  String _configFilePath = "";
  String get configFilePath => _configFilePath;

  var _settingsStatus = SettingsStatus.loading;
  SettingsStatus get settingsStatus => _settingsStatus;

  Map<String, dynamic>? _configContent;

  Future<void> _readConfig() async {
    _configFilePath = await getConfigFilePath();
    if (!await File(_configFilePath).exists()) {
      await _copyDefaultConfig();
    }

    try {
      _configContent = await loadYamlConfig(_configFilePath);
      developer.log('Config Content: $_configContent');
    } catch (e) {
      developer.log('Error reading config file: $e');
    }
  }

  Future<void> _copyDefaultConfig() async {
    final defaultConfigData = await rootBundle.load('assets/config/default_sys.yml');
    final directory = await getApplicationSupportDirectory();
    final configDirectory = Directory(path.join(directory.path, 'config'));
    if (!await configDirectory.exists()) {
      await configDirectory.create(recursive: true);
    }
    final configFilePath = path.join(configDirectory.path, 'config.yml');
    await File(configFilePath).writeAsBytes(defaultConfigData.buffer.asUint8List());
    developer.log('Default config copied to $configFilePath');
  }

  Future loadingConfigFile() async {
    _settingsStatus = SettingsStatus.loading;
    await _readConfig();
    _settingsStatus = SettingsStatus.loaded;
    developer.log(_configFilePath);
    notifyListeners();
  }

  void updateConfigFileIfNeeded() async {
    // 加载默认配置文件
    final defaultConfigData = await rootBundle.loadString('assets/config/default_sys.yml');
    final yamlMap = loadYaml(defaultConfigData);
    Map<String, dynamic>? defaultConfig;
    if (yamlMap is Map) {
      defaultConfig = yamlMap.cast<String, dynamic>();
    }
    try {
      _configFilePath = await getConfigFilePath();
      _configContent = await loadYamlConfig(_configFilePath);
    } catch (e) {
      developer.log('Error reading config file: $e');
    }
    // developer.log('Default: $defaultConfig');
    // developer.log('Config Content: $_configContent');

    int defaultVersion = defaultConfig?['version'] ?? 0;
    int cacheVersion = _configContent?['version'] ?? 0;

    developer.log("defaultVersion $defaultVersion, cacheVersion $cacheVersion");

    if (defaultVersion > cacheVersion) {
      developer.log("新版本配置文件 $defaultVersion, 更新app配置文件");
      _settingsStatus = SettingsStatus.updating;
      _configContent = _updateConfig(_configContent, defaultConfig);
      _configContent?['version'] = defaultVersion; // 把版本号更上去
      logger.i('更新后的 _configContent $_configContent');
      final writer = YamlWriter();
      await File(configFilePath).writeAsString(writer.write(_configContent));
      _settingsStatus = SettingsStatus.loaded;
      notifyListeners();
    }
  }

  Map<String, dynamic>? _updateConfig(Map<String, dynamic>? oldConfigContent, Map<String, dynamic>? newConfigContent) {
    if (oldConfigContent == null || newConfigContent == null) return oldConfigContent;

    // 创建一个新的Map来存储更新后的内容
    Map<String, dynamic> updatedConfigContent = Map.from(oldConfigContent);

    newConfigContent.forEach((key, value) {
      if (!updatedConfigContent.containsKey(key)) {
        // 如果旧的Map中不包含当前键，则直接添加键值对到新的Map中
        updatedConfigContent[key] = value;
      } else if (updatedConfigContent[key] is Map<String, dynamic> && value is Map<String, dynamic>) {
        // 如果当前键对应的值是Map类型，则递归调用_updateConfig函数，并更新新的Map中对应的值
        updatedConfigContent[key] = _updateConfig(updatedConfigContent[key], value);
      }
    });

    return updatedConfigContent;
  }
}
