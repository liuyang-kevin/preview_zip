import 'dart:io';

import 'package:archive/archive.dart';
import 'package:bitsdojo_window/bitsdojo_window.dart';
import 'package:cross_file/cross_file.dart';
import 'package:desktop_drop/desktop_drop.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:video_washer/widgets/settings_wrapper.dart';
import 'package:window_manager/window_manager.dart';

import 'cli/commond.dart';
import 'cli/logger.dart';
import 'inner_server.dart';
import 'key.dart';
import 'model/config/sys.dart';
import 'model/vm/global.dart';
import 'pages/project_page.dart';
import 'pages/webview_page.dart';
import 'widgets/base/app.dart';
import 'widgets/folder_tree_view.dart';
import 'widgets/menu_bar.dart';

void main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isMacOS || Platform.isLinux) {
    await windowManager.ensureInitialized();
  }
  if (args.isNotEmpty) {
    // 带参数运行,去另外App
    logger.i('main run with args $args');
    var options = CommandLineOptions();
    options.parse(args);
  } else {
    runApp(const WasherApp());
  }

  // bitsdojo_window 库提供的调整窗口位置
  doWhenWindowReady(() {
    final win = appWindow;
    const initialSize = Size(1200, 900);
    // win.minSize = initialSize;
    win.size = initialSize;
    win.alignment = Alignment.center;
    // win.title = "Custom window with Flutter";
    win.show();
  });
}

class WasherApp extends StatelessWidget {
  const WasherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<SysSettingsVM>(
      create: (context) {
        final vm = SysSettingsVM();
        vm.loadingConfigFile().then((value) {
          vm.updateConfigFileIfNeeded();
        });
        return vm;
      },
      child: SettingsWrapper(
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: baseApptheme,
          navigatorKey: navigatorKey,
          initialRoute: '/',
          routes: {
            '/': (context) => const ProjectPage(),
            '/detail': (context) => const DetailPage(),
          },
        ),
      ),
    );
  }
}

class LeftSide extends StatelessWidget {
  const LeftSide({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: 200,
        child: Container(
            color: sidebarColor,
            child: Column(
              children: [WindowTitleBarBox(child: MoveWindow()), Expanded(child: Container())],
            )));
  }
}
