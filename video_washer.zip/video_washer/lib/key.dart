import 'package:flutter/material.dart';

final navigatorKey = GlobalKey<NavigatorState>();
