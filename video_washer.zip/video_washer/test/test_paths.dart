import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:video_washer/model/config/sys.dart';

void main() {
  testWidgets('Counter increments smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    // await tester.pumpWidget(const MyApp());

    await logPathProviderPaths();

    await Future.delayed(const Duration(seconds: 3));
    exit(0);
  });
}
